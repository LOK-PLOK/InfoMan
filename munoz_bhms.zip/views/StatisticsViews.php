<?php

require 'GeneralViews.php';
require '../controllers/StatisticsController.php';

class StatisticsViews extends GeneralViews {
}

?>